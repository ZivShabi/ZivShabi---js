


function resetGame() { gameData.players.forEach(player => { player.position = 0; }); placePlayers(); }
function startGame() {
    if (gameData.boardSize === 0 || gameData.snakesAndLaddersCount === 0 || gameData.players.length === 0) {
        displayErrorMessage('אנא הזן את כל הפרטים'); return;
    }

    gameData.playerPositions = new Array(gameData.players.length).fill(0);
    gameData.snakes = {};
    gameData.ladders = {};
    const snakePositions = generateRandomPositions(gameData.snakesAndLaddersCount);
    const ladderPositions = generateRandomPositions(gameData.snakesAndLaddersCount);

    snakePositions.forEach(pos => {
        let endPos;
        do { endPos = pos - getRandomPosition(gameData.boardSize / 2); }
        while (endPos < 1); gameData.snakes[pos] = endPos;
    });

    ladderPositions.forEach(pos => {
        let endPos;
        do { endPos = pos + getRandomPosition(gameData.boardSize / 2); }
        while (endPos > gameData.boardSize); gameData.ladders[pos] = endPos;
    });

    document.getElementById('gameBoard').style.display = 'grid';
    initializeGame();
}

function initializeGame() {
    const board = document.getElementById('gameBoard');
    board.style.gridTemplateColumns = `repeat(${Math.sqrt(gameData.boardSize)}, 1fr)`;
    board.style.gridTemplateRows = `repeat(${Math.sqrt(gameData.boardSize)}, 1fr)`;

    board.innerHTML = '';

    for (let i = 1; i <= gameData.boardSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.textContent = i;
        if (gameData.snakes[i]) {
            const snake = document.createElement('div');
            snake.className = 'snake';
            snake.style.height = `${gameData.snakeAndLadderSize}px`;
            cell.appendChild(snake);
        }
        if (gameData.ladders[i]) {
            const ladder = document.createElement('div');
            ladder.className = 'ladder';
            ladder.style.height = `${gameData.snakeAndLadderSize}px`;
            cell.appendChild(ladder);
        }
        gameData.players.forEach((player, index) => {
            if (gameData.playerPositions[index] === i) {
                const playerElem = document.createElement('div');
                playerElem.className = 'player';
                if (index === gameData.currentPlayer) {
                    playerElem.classList.add('special-player');
                }
                cell.appendChild(playerElem);
            }
        });
        board.appendChild(cell);
    }
}
const horizontalPosition = '50%';
const verticalPosition = '50%';
function drawBoard() {
    const board = document.getElementById('gameBoard');
    board.innerHTML = '';
    for (let i = 1; i <= gameData.boardSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.textContent = i;
        if (gameData.snakes[i]) {
            const snake = document.createElement('div');
            snake.className = 'snake';
            snake.innerHTML = `<div class="snake head"> 
                     <div class="snake eye"></div></div> `;
            snake.style.position = 'absolute';
            snake.style.transform = 'translate(-50%, -50%)rotate(-45deg)';
            snake.style.left = horizontalPosition;
            snake.style.top = verticalPosition;
            snake.style.height = `${gameData.snakeAndLadderSize}px`;
            cell.appendChild(snake);
        }
        if (gameData.ladders[i]) {
            const ladder = document.createElement('div');
            ladder.className = 'ladder';
            ladder.style.position = 'absolute';
            ladder.style.transform = 'translate(-50%, -50%) rotate(-45deg)';
            ladder.style.left = horizontalPosition;
            ladder.style.top = verticalPosition;
            ladder.style.height = `${gameData.snakeAndLadderSize}px`;
            ladder.innerHTML = `
                      <div class="steps">
                        <div class="step"></div>
                        <div class="step"></div>
                        <div class="step"></div>
                        <div class="step"></div>
                    </div>`;
            cell.appendChild(ladder);
        }
        gameData.players.forEach((player, index) => {
            if (gameData.playerPositions[index] === i) {
                const playerElem = document.createElement('div');
                playerElem.className = 'player';
                playerElem.setAttribute('data-index', gameData.playerPositions[index] + 1);

                if (index === gameData.currentPlayer) {
                    playerElem.classList.add('special-player');
                }
                cell.appendChild(playerElem);
            }
        });
        board.appendChild(cell);
    } initializeGame(); submitPlayerNames();

}



function movePlayer(roll) {
    const startPos = gameData.playerPositions[gameData.currentPlayer];
    let newPos = startPos + roll;

    if (newPos > gameData.boardSize) {
        newPos = gameData.boardSize;
    }

    for (let i = startPos + 1; i <= newPos; i++) {
        setTimeout((pos) => {
            gameData.playerPositions[gameData.currentPlayer] = pos;
            drawBoard();

            if (gameData.snakes[pos]) {
                displayErrorMessage(`הופה! ${gameData.players[gameData.currentPlayer]} ננשך/ה על ידי נחש ונפל/ה אחורה!`);
                gameData.playerPositions[gameData.currentPlayer] = gameData.snakes[pos];
                newPos = gameData.snakes[pos];
                drawBoard();  // לעדכן את הלוח לאחר שינוי המיקום
            } else if (gameData.ladders[pos]) {
                displayErrorMessage(`מזל טוב! ${gameData.players[gameData.currentPlayer]} טיפס/ה בסולם!`);
                gameData.playerPositions[gameData.currentPlayer] = gameData.ladders[pos];
                newPos = gameData.ladders[pos];
                drawBoard();  // לעדכן את הלוח לאחר שינוי המיקום
            }

            if (gameData.playerPositions.includes(gameData.boardSize)) {
                isGameOver = true;
                gameover();
                return;
            }
        }, 1000 * (i - startPos), i);
    }

    setTimeout(() => {
        if (!isGameOver) {
            gameData.currentPlayer = (gameData.currentPlayer + 1) % gameData.players.length;
        }
    }, 1000 * (newPos - startPos + 1));
}
function moveSnakesAndLaddersRandom() {
    gameData.snakes = {};
    gameData.ladders = {};
    let maxAttempts = 100;
    const snakePositions = generateRandomPositions(gameData.snakesAndLaddersCount);
    const ladderPositions = generateRandomPositions(gameData.snakesAndLaddersCount);

    snakePositions.forEach(pos => {
        let attempts = 0;
        let endPos;
        do {
            endPos = pos - getRandomPosition(gameData.boardSize / 2);
            attempts++;
        } while (endPos < 1 && attempts < maxAttempts);
        if (attempts >= maxAttempts) {
            endPos = 1;
        }
        gameData.snakes[pos] = endPos;
    });

    ladderPositions.forEach(pos => {
        let attempts = 0;
        let endPos;
        do {
            endPos = pos + getRandomPosition(gameData.boardSize / 2);
            attempts++;
        } while (endPos > gameData.boardSize && attempts < maxAttempts);
        if (attempts >= maxAttempts) {
            endPos = gameData.boardSize;
        }
        gameData.ladders[pos] = endPos;
    });

    drawBoard();
}
function displayErrorMessage(mission) {
    let positionMessage = "";
    let errorMessageElement = document.querySelector(".mission");
    if (errorMessageElement) {
        errorMessageElement.textContent = `${mission} ${positionMessage}`;
        errorMessageElement.style.display = "block";
        setTimeout(() => { errorMessageElement.style.display = "none"; }, 1000 * 5);
    } else {
        console.error("Error: .mission element not found.");
    }
}
function movePlayerAnimated() {
    const currentPlayer = document.querySelector('.player.special-player');
    if (!currentPlayer) return;

    const targetCell = document.querySelector(`.cell:nth-child(${gameData.playerPositions[gameData.currentPlayer]})`);
    const playerSize = currentPlayer.offsetWidth; // assuming player is square
    const targetPos = targetCell.getBoundingClientRect();

    currentPlayer.animate([
        { transform: `translate(0, 0)` },
        { transform: `translate(${targetPos.left - playerSize / 2}px, ${targetPos.top - playerSize / 2}px)` }
    ], {
        duration: 1000,
        easing: 'ease-in-out'
    }); moveSnakesAndLaddersAnimated();
}
function createPlayerElement(playerIndex) {
    const playerElement = document.createElement('div');
    playerElement.className = 'player';
    playerElement.style.backgroundColor = ['red', 'blue', 'green', 'yellow'][playerIndex % 4];
    return playerElement;
}
function gameover() {
    const winnerIndex = gameData.playerPositions.findIndex(position => position === gameData.boardSize);
    if (winnerIndex !== -1) { // בדיקה אם יש מנצח
        const winner = gameData.players[winnerIndex];
        alert(`סיימתם את המשחק! תודה על השתתפותכם, המנצח הוא: ${winner}`);
    }
    const board = document.getElementById('gameBoard');
    if (!board.innerHTML) { // רק אם הלוח עדיין לא נוצר
        drawBoard();
    }
    gameData.boardSize = 0;
    gameData.snakesAndLaddersCount = 0;
    gameData.snakeAndLadderSize = 0;
    gameData.currentPlayer = 0;
    gameData.playerPositions = [];
    gameData.players = [];
    gameData.snakes = {};
    gameData.ladders = {};
    document.getElementById('gameBoard').style.display = 'none';
}
initializeGame()
