let gameData = {
    arrPlayers: [
        { location: 1, player: "👨‍⚖️1", name: "", Points: 0 },
        { location: 1, player: "👨‍⚖️2", name: "", Points: 0 },
        { location: 1, player: "👨‍⚖️3", name: "", Points: 0 },
        { location: 1, player: "👨‍⚖️4", name: "", Points: 0 }
    ],

    selectedSnakesAndLadders: [
        { type: 'snake', start: 30, end: 10 },
        { type: 'ladder', start: 45, end: 70 }
    ],
    snakes: [
        { position: 16, size: 'large' },
        { position: 40, size: 'medium' },
        { position: 55, size: 'small' },
        { position: 72, size: 'medium' }
    ],
    ladders: [
        { position: 10, size: 'large' },
        { position: 25, size: 'medium' },
        { position: 45, size: 'small' },
        { position: 85, size: 'medium' }
    ]
};

let playerStone = document.createElement('div');

const updateBoardSizeButton = document.getElementById('updateBoardSize');
updateBoardSizeButton.addEventListener('click', updateBoardSize);

function updateBoardSize() {
    const newSize = parseInt(document.getElementById('boardSize').value);
    const snakeAndLadderCount = parseInt(document.getElementById('snakeAndLadderCount').value);
    updateBoardWithNewSize(newSize, snakeAndLadderCount);
}

function updateBoardWithNewSize(newSize, snakeAndLadderCount) {
    generateBoard(newSize);
    updateGameDataWithCount(newSize, snakeAndLadderCount);
}

function updateGameDataWithCount(newSize, snakeAndLadderCount) {
    gameData.boardSize = newSize;
    gameData.snakes = [];
    gameData.ladders = [];

    for (let i = 0; i < snakeAndLadderCount; i++) {
        const snakePosition = generateRandomPositions(1, 0, newSize * newSize - 1)[0];
        const ladderPosition = generateRandomPositions(1, 0, newSize * newSize - 1)[0];

        gameData.snakes.push({ position: snakePosition, size: 'medium' });
        gameData.ladders.push({ position: ladderPosition, size: 'medium' });
    }

    gameData.arrPlayers.forEach(player => {
        player.location = 1;
    });
}

function generateRandomPositions(count, min, max) {
    const positions = new Set();
    while (positions.size < count) {
        positions.add(Math.floor(Math.random() * (max - min + 1)) + min);
    }
    return Array.from(positions);
}

let mission = document.createElement('p');
mission.style.fontSize = '20px';
document.body.appendChild(mission);

function generateBoard(newSize) {
    const container = document.querySelector('.board-container');
    container.innerHTML = '';
    for (let i = 0; i < newSize; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.textContent = i + 1;
        container.appendChild(cell);

        if (i % 20 < 10) { cell.classList.add('even-row'); }
        else { cell.classList.add('odd-row'); }

        const snake = gameData.snakes.find(s => s.position === i);
        const ladder = gameData.ladders.find(l => l.position === i);

        if (snake) {
            const snakeElement = createSnakeElement(snake.size);
            cell.appendChild(snakeElement);
        } else if (ladder) {
            const ladderElement = createLadderElement(ladder.size);
            cell.appendChild(ladderElement);
        }
    }
}

let element = document.getElementById(`id${1}`);
let line; // הגדרת המשתנה line מחוץ לתנאי if

if (element !== null) {
    let rect = element.getBoundingClientRect();
    console.log('Top:', rect.top);
    line = document.createElement('div'); // השמה של הערך למשתנה line
    line.classList.add('line');
} else {
    console.error('Element not found!');
}

const btn = document.createElement('button');
btn.classList.add('btn');
btn.innerText = 'הטל קובייה';
btn.disabled = true;

// בדיקה האם line מוגדר לפני שניסיון להוסיף אליו כל משהו
if (typeof line !== 'undefined') {
    line.appendChild(btn);
} else {
    console.error('Line not defined!');
}
let select = document.createElement('select');
line.appendChild(select);
let option = document.createElement("option");
option.value = "";
option.text = "'מס שחקנים"
select.appendChild(option);

for (let i = 1; i <= 4; i++) {
    option = document.createElement("option");
    option.value = i;
    option.text = i;
    select.appendChild(option);
}

let cube = document.createElement('img');
cube.classList.add('cube');
line.appendChild(cube);
document.body.appendChild(line);

let numberPlayers = 0;
let turn;
let form = document.createElement('form');
let inputName = document.createElement('input');
let submitButton = document.createElement('input');

select.addEventListener('change', () => {
    numberPlayers = select.value;
    turn = Math.floor(Math.random() * numberPlayers);
    document.body.appendChild(form);
    let i = form.querySelectorAll('input').length;
    while (i > numberPlayers) {
        form[i - 1].remove();
        i--;
    }
    for (i; i < numberPlayers; i++) {
        let inputName = document.createElement('input');
        inputName.setAttribute('id', `input${i + 1}`);
        inputName.type = 'text';
        inputName.required = true;
        inputName.placeholder = `שם של שחקן מספר${i + 1}`;
        form.appendChild(inputName);
    }
    submitButton.setAttribute('id', 'button');
    submitButton.type = 'submit';
    submitButton.value = 'הזן שמות';
    form.appendChild(submitButton);
});

submitButton.addEventListener('click', () => {
    for (let i = 0; i < numberPlayers; i++) {
        let string = document.getElementById(`input${i + 1}`).value;
        gameData.arrPlayers[i].name = string;
        let playerStone = document.createElement('div');
        playerStone.setAttribute('id', `player${i}`);
        playerStone.innerText = string;
        playerStone.classList.add("player");
        const centerX = (rect.left + rect.right) / 2;
        const centerY = (rect.top + rect.bottom) / 2;

        playerStone.style.top = `${centerY}px`;
        playerStone.style.left = `${centerX}px`;
        playerStone.style.backgroundColor = getRandomColor();
        document.body.appendChild(playerStone);
    }
    mission.innerHTML = `מתחיל-${gameData.arrPlayers[turn].name}`;
    document.body.removeChild(form);
    select.disabled = true;
    btn.disabled = false;
});

btn.addEventListener('click', function () {
    let rollingSound = new Audio('tools/SnakesAndLadder_rpg-dice-rolling-95182.mp3');
    if (turn == numberPlayers - 1)
        mission.innerHTML = `זה התור של שחקן - ${gameData.arrPlayers[0].name}`;
    else
        mission.innerHTML = `זה התור של שחקן - ${gameData.arrPlayers[turn + 1].name}`;
    rollingSound.play();
    btn.disabled = true;
    select.disabled = true;
    throwCube(gameData.arrPlayers[turn]);
});

function throwCube(player) {
    let rollingSound = new Audio();
    let element = document.getElementById(`id${player.location}`);
    if (element) {
        let newText = element.innerHTML.replace(player.player, "");
        element.innerHTML = newText;
    }
    cube.src = 'tools/diceroll.gif';
    setTimeout(() => {
        btn.disabled = false;
        let num = Math.floor(Math.random() * 6) + 1;
        cube.src = `tools/dice${num}.svg`;
        let remember = player.location;
        player.location = player.location + num;

        switch (player.location) {
            case 4:
                player.location = 14;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 8:
                player.location = 37;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 22:
                player.location = 32;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 23:
                player.location = 13;
                rollingSound.src = 'tools/land2-43790.mp3';
                rollingSound.play();
                break;
            case 30:
                player.location = 19;
                rollingSound.src = 'tools/land2-43790.mp3';
                rollingSound.play();
                break;
            case 43:
                player.location = 63;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 45:
                player.location = 55;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 51:
                player.location = 41;
                rollingSound.src = 'tools/land2-43790.mp3';
                rollingSound.play();
                break;
            case 60:
                player.location = 79;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 61:
                player.location = 82;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 68:
                player.location = 47;
                rollingSound.src = 'tools/land2-43790.mp3';
                rollingSound.play();
                break;
            case 78:
                player.location = 88;
                rollingSound.src = 'tools/climb.mp3';
                rollingSound.play();
                break;
            case 83:
                player.location = 74;
                rollingSound.src = 'tools/land2-43790.mp3';
                rollingSound.play();
                break;
            case 100:
                mission.innerHTML = `כל הכבוד ${player.name} ניצחת!`;
                player.Points++;
                for (let i = 0; i < numberPlayers; i++) {
                    document.getElementById(`id${gameData.arrPlayers[i].location}`).innerText = "";
                    gameData.arrPlayers[i].location = 1;
                    let loc = document.getElementById(`id${1}`).getBoundingClientRect();
                    let playerStone = document.getElementById(`player${i}`);
                    playerStone.style.top = `${loc.top}px`;
                    playerStone.style.left = `${loc.left}px`;
                }
                select.disabled = false;
                break;
            default:
                if (player.location > 100) {
                    player.location -= num;
                    remember -= num;
                    mission.innerHTML = 'קצת יותר מדי';
                }
                break;
        }

        document.getElementById(`id${player.location}`).innerText = player.player;
        let loc = document.getElementById(`id${player.location}`).getBoundingClientRect();
        let loc2 = document.getElementById(`id${remember + num}`).getBoundingClientRect();
        let playerStone = document.getElementById(`player${turn}`);
        if (remember + num != player.location) {
            setTimeout(() => {
                playerStone.style.top = `${loc.top + scrollTop + 5}px`;
                playerStone.style.left = `${loc.left + scrollLeft + 5}px`;
            }, 800);
        }

        const scrollTop = window.scrollY || document.documentElement.scrollTop;
        const scrollLeft = window.scrollX || document.documentElement.scrollLeft;
        playerStone.style.top = `${loc2.top + scrollTop + 15}px`;
        playerStone.style.left = `${loc2.left + scrollLeft + 10}px`;

        turn++;
        if (turn >= numberPlayers) {
            turn = 0;
        }
    }, 500);
}

function getRandomColor() {
    const red = Math.floor(Math.random() * 256);
    const green = Math.floor(Math.random() * 256);
    const blue = Math.floor(Math.random() * 256);
    return `rgb(${red}, ${green}, ${blue})`;
}